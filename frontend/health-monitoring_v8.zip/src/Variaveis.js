export default function BACK_URL(){
    return 'http://35.193.239.101:8082/';
}  
